IBM Sterling B2B Integrator (B2Bi) Java Database Connectivity (JDBC) Test Tool

Overview:

The B2Bi JDBC Tester (DBConnTest.jar)  introduces a way to troubleshoot, validate, and test JDBC connections to a database.

This tool meets the need of a Java Program for testing JDBC connections.  
IBM Sterling B2B Integrator supports JDBC Type-4 drivers  to connect to a database.

Download the DBConnTest.zip
https://www.ibm.com/developerworks/community/forums/html/threadTopic?id=1f367052-ca67-47ad-9e69-c2b3cc81a783

The zip file contains the DBConnTest.jar, dbconntest.properties, and this readme.txt.

Use Case Scenarios:

- Test the jdbc connection for a brand new installation/upgrade of B2Bi, using the same Java version and JDBC driver as required by the B2Bi system requirements
- Test the B2Bi jdbc driver from the  <B2Bi-install>/dbjar/jdbc/ directory
- Test 3rd party pool connections
- Troubleshoot "db connection failed" type errors
- Validate database connection credentials such as user name, password, host name and port

Property File Parameters
 
Parameter   | Valid Value
            
DB_VENDOR   | Oracle       
            |  DB2          
            |  MSSQL        
            |  DB2i_app     
            |  DB2i_toolbox 
            
DB_HOST     | IP or Host Name of Database Server
            
DB_PORT     | TCP/IP Database Port
            
DB_DATA     | Database Catalogue Name (SID or ServiceName in Oracle)
            
DB_USER     | Database User
            
DB_PASS     | Database Password

DRIVER_PATH | Full Path to Type 4 JDBC Driver                                                         
            | Example: /opt/jdbc/ojdbc7.jar                                                           
            | For Windows "\" escape characters are required. Example: C\:\\ORACLE\\Driver\\ojdbc7.jar

Installation

1) Download DBConnTest.zip and unzip all the contents into the same directory
2) Edit dbconntest.properties
Fill in parameters:

DB_VENDOR=
DB_HOST=
DB_PORT=
DB_DATA=
DB_USER=
DB_PASS=
DRIVER_PATH=

3)  Open command prompt to the directory with the extracted files and execute the following command:
java -jar DBConnTest.jar

If testing a B2Bi connection use the same Java executable that the application is using.
Example: <B2Bi_Install>/jdk/bin/java 