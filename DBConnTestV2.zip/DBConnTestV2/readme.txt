IBM Sterling B2B Integrator (B2Bi) Java Database Connectivity (JDBC) Test Tool

Overview:

The B2Bi JDBC Tester V2 (DBConnTestV2.jar) enhances the ability to troubleshoot, validate and test JDBC connections to a database.

This tool meets the need of a Java Program for testing JDBC connections.  
IBM Sterling B2B Integrator supports JDBC Type-4 drivers  to connect to a database.

Download the DBConnTestV2.zip
https://github.com/afuruk/DBConnTest/blob/master/DBConnTestV2.zip

The zip file contains the DBConnTestV2.jar, dbconntest.properties, and this readme.txt.

Use Case Scenarios:

- Test the jdbc connection for a brand new installation/upgrade of B2Bi, using the same Java version and JDBC driver as required by the B2Bi system requirements
- Test the B2Bi jdbc driver from the  <B2Bi-install>/dbjar/jdbc/ directory
- Test 3rd party pool connections
- Troubleshoot "db connection failed" type errors
- Validate database connection credentials such as user name, password, host name and port

Property File Parameters
 
Parameter   			| Valid Value
            
DB_VENDOR   			|  Oracle       
						|  DB2          
						|  MSSQL        
						|  DB2i_app     
						|  DB2i_toolbox 
            
DB_HOST 				| IP or Host Name of Database Server
            
DB_PORT     			| TCP/IP Database Port
            
DB_DATA     			| Database Catalogue Name (SID or ServiceName in Oracle)
            
DB_USER     			| Database User
            
DB_PASS     			| Database Password

DRIVER_PATH 			| Full Path to Type 4 JDBC Driver                                                         
						| Example: /opt/jdbc/ojdbc7.jar                                                           
						| For Windows "\" escape characters are required. Example: C\:\\ORACLE\\Driver\\ojdbc7.jar
			
SSLTLS					| false (default) or true - instruction to use SSL or not.
  
TRUSTSTORE_PATH			| If SSLTLS=true - Path to the JKS keystore.  Example:  C:\:\\temp\DBConnTestV2\truststore.jks
TRUSTSTORE_PASSWORD		| If SSLTLS=true - Password to the JKS file specified in TRUSTSTORE_PATH.  Example: OracleTrustStorePasswd
J2SSE_OVERRIDE_TLS		| IF DB_VENDOR=MSSQL.  false (default) or true


Installation

1) Download DBConnTest.zip and unzip all the contents into the same directory
2) Edit dbconntest.properties
Fill in parameters:

DB_VENDOR=
DB_HOST=
DB_PORT=
DB_DATA=
DB_USER=
DB_PASS=
DRIVER_PATH=
SSLTLS=					(optional)
TRUSTSTORE_PATH=		(optional)
TRUSTSTORE_PASSWORD=	(optional)
J2SSE_OVERRIDE_TLS=		(optional)


3)  Open command prompt to the directory with the extracted files and execute the following command:
java -jar DBConnTest.jar

If testing a B2Bi connection use the same Java executable that the application is using.
Example: <B2Bi_Install>/jdk/bin/java 